/**
 * 
 */
package com.howtodoinjava.JerseyJSONP.Test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.howtodoinjava.JerseyJSONP.JerseyJSONP;

/**
 * @author eprmahi
 *
 */
public class JerseyJSONPTest extends JerseyJSONP {

	/**
	 * Test method for {@link com.howtodoinjava.JerseyJSONP.JerseyJSONP#getAllEmployees()}.
	 */
	@Test
	public void testGetAllEmployees() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link com.howtodoinjava.JerseyJSONP.JerseyJSONP#updateEmployeeById(java.lang.Integer)}.
	 */
	@Test
	public void testUpdateEmployeeById() {
		fail("Not yet implemented");
	}

}
