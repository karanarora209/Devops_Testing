/**
 * 
 */
package com.howtodoinjava.JerseyJSONP;

import java.util.List;


/**
 * @author eprmahi
 *
 */
public class Employees {
	
	private List<Employee> employeeList;
	 
    public List<Employee> getEmployeeList() {
        return employeeList;
    }
 
    public void setEmployeeList(List<Employee> employeeList) {
        this.employeeList = employeeList;
    }
}
