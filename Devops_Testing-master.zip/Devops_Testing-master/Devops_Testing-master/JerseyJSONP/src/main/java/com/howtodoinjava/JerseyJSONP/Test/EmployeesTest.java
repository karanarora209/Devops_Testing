package com.howtodoinjava.JerseyJSONP.Test;

import static org.junit.Assert.*;

import org.junit.Test;

public class EmployeesTest {

	@Test
	public void testGetEmployeeList() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetEmployeeList() {
		fail("Not yet implemented");
	}

}
