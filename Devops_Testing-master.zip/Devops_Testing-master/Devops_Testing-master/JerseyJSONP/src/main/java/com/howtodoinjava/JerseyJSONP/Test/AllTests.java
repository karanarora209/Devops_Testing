package com.howtodoinjava.JerseyJSONP.Test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ EmployeesTest.class, EmployeeTest.class, JerseyJSONPTest.class })
public class AllTests {

}
